<?php
    /*
    * Plugin Name: Loyalty_card_Marion 
    * Author: Marion
    * Description: Plugin d'affichage "Hey"                   
    */

    function renvoie(){
        echo '<i>' . 'Hey !' . '</i>';
    }

    add_shortcode('plug', 'renvoie');

?>
